# 1. 导入库
import pandas as pd
import jieba
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 2. 加载数据（示例格式）
data = pd.read_csv(R'E:\学习\ai\慕课llm算法特训002.LLM大语音模型算法特训 带你转型AI大语音模型算法工程师\源码+PDF课件\源码\llm\llm_course\test\ChnSentiCorp_htl_all.csv')  # 假设包含'review'和'sentiment'列
# 正向评价标1，负向标0
print(data.head(3))

# 处理缺失值
data['review'] = data['review'].fillna('')  # 将NaN值替换为空字符串

# 3. 数据预处理
# 3.1 分词
def cut_words(text):
    return " ".join(jieba.cut(text))

data['review'] = data['review'].apply(cut_words)

# 3.2 特征抽取
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(data['review'])
y = data['label']

print(X[0])

# 4. 模型训练
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
# 贝叶斯模型   accuracy:0.7303732303732303
clf = MultinomialNB()
clf.fit(X_train, y_train)
# 逻辑回归模型  accuracy:0.8693693693693694
#clf = LogisticRegression()  # 创建逻辑回归模型实例
#clf.fit(X_train, y_train)  # 训练逻辑回归模型

# 5. 模型评估
y_pred = clf.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("accuracy: ", accuracy)




print(data.head(1))
print(data.shape)


